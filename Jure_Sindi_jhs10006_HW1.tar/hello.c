#include "types.h"
#include "user.h"

// Task 1
int main (void) {
    printf(1, "Hello, World!");
    exit();
}